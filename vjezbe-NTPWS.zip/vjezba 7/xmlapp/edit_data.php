<?php
	
	// getting dependencies
	require_once("include/login_check.php");
	require_once("include/db.php");
	require_once("include/header.php");
	
	// getting the car's id from url
	$car_id = $database_connection->escape_string($_GET['id']);
	
	// if you are posting
	if(!empty($_POST)){
		
		// query for updating car
		$query = "UPDATE cars SET name = ?, color = ?, max_speed = ?, number_of_seats = ? WHERE id = ?;";
		
		// preparing the statement
		$stmt = $database_connection->prepare($query);
		
		// binding the parameters
		$stmt->bind_param('ssiii', $_POST['name'], $_POST['color'], $_POST['max_speed'], $_POST['number_of_seats'], $car_id);
		
		// executing the statement
		$stmt->execute();
		
		// redirecting to show_data.php
		header("Location: " . URL . "show_data.php");
	}
	
	// if there is $_GET['id'] variable
	if(isset($_GET['id'])){
		
		// query for selecting cars with some id
		$query = "SELECT name, color, max_speed, number_of_seats FROM cars WHERE id = ?;";
		
		// preparing the statement
		$stmt = $database_connection->prepare($query);
		
		// binding parameters
		$stmt->bind_param('i', $car_id);
		
		// executing the query
		$stmt->execute();
		
		// binding result to variables
		$stmt->bind_result($car_name, $car_color, $car_max_speed, $car_number_of_seats);
		
		// fetching the result
		$stmt->fetch();
		
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title><?php echo APP_TITLE; ?></title>
		<link href="style/main.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<?php echo $header; ?>
		<form name="input" action="http://<?php echo $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"]; ?>" method="POST">
			Id: <?php echo $car_id; ?><br />
			Name: <input type="text" name="name" value="<?php echo $car_name; ?>" /><br />
			Color: <input type="text" name="color" value="<?php echo $car_color; ?>" /><br />
			MaxSpeed: <input type="text" name="max_speed" value="<?php echo $car_max_speed; ?>" /><br />
			NumberOfSeats: <input type="text" name="number_of_seats" value="<?php echo $car_number_of_seats; ?>" /><br />
			<input type="submit" value="Submit">
		</form>
	</body>
</html>