<?php
	
	// loading dependencies
	require_once("include/login_check.php");
	require_once("include/check_permissions.php");
	require_once("include/header.php");
	
?>

<!DOCTYPE html>
<html>
	<head>
		<title><?php echo APP_TITLE; ?></title>
		<link href="style/main.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<?php echo $header; ?>
	</body>
</html>