<?php
	// getting dependencies
	require_once("include/login_check.php");
	require_once("include/db.php");
	require_once("include/header.php")
?>

<!DOCTYPE html>
<html>
	<head>
		<title><?php echo APP_TITLE; ?></title>
		<link href="style/main.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<?php echo $header; ?>
		<div id="show_data">
			<table>
				<?php
					
					// query for getting cars
					$query = "SELECT id, name, color, max_speed, number_of_seats FROM cars;";
					
					// preparing the statement
					$stmt = $database_connection->prepare($query);
					
					// executing the statement
					$stmt->execute();
					
					// binding the result to variables
					$stmt->bind_result($car_id, $car_name, $car_color, $car_max_speed, $car_number_of_seats);
					
					// table headers
					echo "<tr><th>Id</th><th>Name</th><th>Color</th><th>MaxSpeed</th><th>NumberOfSeats</th></tr>";
					
					// fetching the result
					while($stmt->fetch()){
						
						// table rows
						$row = "<tr>";
						$row .= 
									'<td>' . $car_id . '</td><td>' . $car_name . '</td>
									<td>' . $car_color . '</td><td>' . $car_max_speed . '</td>
									<td>' . $car_number_of_seats . '</td><td><a href="' . URL."edit_data.php?id=". $car_id . '">Edit</a></td>
									<td><a href="' . URL."remove_data.php?id=". $car_id . '">Remove</a></td>';
						$row .= "</tr>";
						echo $row;
					}
				?>
			</table>
		</div>
	</body>
</html>