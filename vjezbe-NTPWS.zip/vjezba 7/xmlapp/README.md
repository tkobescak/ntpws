xmlapp
======

Application which allows uploading XML file and parsing it with PHP and allowing CRUD to MySQL.

Configuration:
database - data/database.sql
edit include/globals.php