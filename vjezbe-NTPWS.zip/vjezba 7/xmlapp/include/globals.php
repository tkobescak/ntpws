<?php
	// defining global variables
	define("URL", "http://localhost/xmlapp/");
	define("APP_TITLE", "XMLAPP");
	define("XML_UPLOAD_PATH", "C:/wamp/www/xmlapp/files/");
?>