<?php
	
	// require database connectivity and checking for permissions
	require("db.php");
	require_once("check_permissions.php");
	
	// setting the header, depends on your role (Administrator or User)
	
	if(check_permissions("see_admin_menu")){
		$header = '<div id="main_header"><h1>Welcome to ' . APP_TITLE . '</h1>
			<div id="main_menu">
				<div id="main_menu_left">
					<a href=".">Home</a> | 
					<a href="import_xml.php">ImportXML</a> | 
					<a href="show_data.php">ShowData</a> |
					<a href="users.php">Users</a> 
				</div>
				<div id="main_menu_right"><span id="logged_in_text">Welcome ' . $_SESSION['logged_user']['username'] . ', </span> <a href="logout.php">Logout</a></div>
			</div>
		</div>';
	}else if(check_permissions("see_user_menu")){
		$header = '<div id="main_header"><h1>Welcome to ' . APP_TITLE . '</h1>
			<div id="main_menu">
				<div id="main_menu_left">
					<a href=".">Home</a> | 
					<a href="import_xml.php">ImportXML</a> | 
					<a href="show_data.php">ShowData</a>
				</div>
				<div id="main_menu_right"><span id="logged_in_text">Welcome ' . $_SESSION['logged_user']['username'] . ', </span> <a href="logout.php">Logout</a></div>
			</div>
		</div>';
	}else{
		$header = "";
	}
	
?>