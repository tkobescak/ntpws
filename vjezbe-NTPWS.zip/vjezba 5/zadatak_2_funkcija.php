<?php


function checkStrings($prvi, $drugi){
    if($prvi == $drugi){
        return 0;
    }else{
        return -1;
    }
}