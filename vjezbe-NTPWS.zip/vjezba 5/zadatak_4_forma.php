<!DOCTYPE html>
<html>
<body>

<form action="zadatak_4.php" method="post" enctype="multipart/form-data">
Naziv<input type="file" name="fajl" id="fajl"><br /><br />
<input type="submit" name="submit" value="Upload">
</form>
    
</body>
</html>
