<?php
include("zadatak_2_funkcija.php");

echo checkStrings("bla", "bla");
echo "<br />";
echo checkStrings("bla2", "bla");