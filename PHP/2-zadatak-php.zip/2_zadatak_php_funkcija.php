<?php
function checkStrings ($prvi, $drugi) {
    if ($prvi == $drugi)    {
        return 0;
                            }
    else    {
        return -1;
            }
}

/*
Zadatak:
Potrebno je napisati funkciju koja prihvaćati dva stringa. U slučaju da su obadva stringa identična,
funkcija vraća 0. Ako nisu identični, funkcija vraća ‐1;
U drugu datoteku treba uključiti datoteku s funkcijom i pozvati ju te ispisati rezultat.
*/

?>
