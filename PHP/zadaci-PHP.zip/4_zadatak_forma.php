<!DOCTYPE html>
<html>
<body>

<form action="4-zadatak.php" method="post" enctype="multipart/form-data">
Ime<input type="file" name="dokument" id="dokument"><br /><br />
<input type="submit" name="submit" value="Upload">
</form>
    
</body>
</html>

<!-- 4. Zadatak: Treba napraviti formu koja će dopustiti upload samo slika => "image/jpeg" -->
