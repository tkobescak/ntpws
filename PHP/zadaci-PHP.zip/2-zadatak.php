<?php
include("2_zadatak_php_funkcija.php");

echo checkStrings("nesto", "nesto");
echo "<br />";
echo checkStrings("nesto2", "nesto");

/* 2. Zadatak php:
Potrebno je napisati funkciju koja prihvaćati dva stringa. U slučaju da su obadva stringa identična,
funkcija vraća 0. Ako nisu identični, funkcija vraća ‐1;
U drugu datoteku treba uključiti datoteku s funkcijom i pozvati ju te ispisati rezultat. */

?>
